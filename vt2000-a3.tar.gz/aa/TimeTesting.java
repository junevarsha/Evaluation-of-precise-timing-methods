/**
 Assignment-3
 Submitted by
 Varsha Thirumakil
 */

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

import java.util.*;
import java.util.concurrent.TimeUnit;

import com.google.common.base.Stopwatch;
//import com.google.common.base.Stopwatch;
import com.google.common.base.Ticker;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JFrame;

class TimeTesting {

	static List<Integer> primes = new ArrayList<Integer>();

	public static void main(String args[]) throws InterruptedException {


		Stopwatch timer = Stopwatch.createStarted();
		primeCheck();
		
		System.out.println(" Prime method took: " + timer.stop());
		System.out
		.println("************************************************************");

		Stopwatch timer1 = Stopwatch.createStarted();
		//dataVisc();
		//System.out.println(" DataVisc method took: " + timer1.stop());
		System.out
				.println("************************************************************");

		Stopwatch timer2 = Stopwatch.createStarted();
		//fileCSV();
		//System.out.println(" wrting csv took: " + timer2.stop());
		System.out
				.println("************************************************************");

	}

	public static void fileCSV() {

		BufferedReader bufferedReader = null;
		BufferedWriter bufferedWriter = null;
		try {
			bufferedReader = new BufferedReader(new FileReader(
					"/users/varsha/Downloads/2015/301-720/301-720.csv"));
			bufferedWriter = new BufferedWriter(new FileWriter(
					"/users/varsha/Downloads/v2.csv"));
			String s = "";
			while ((s = bufferedReader.readLine()) != null) {
				bufferedWriter.write(s);
				// write a new line
				bufferedWriter.newLine();
				// flush
				bufferedWriter.flush();
				// System.out.println("Data is written to out.txt");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	public static void dataVisc() {

		// SliceQuad. generateTextureObjects(ControlPanel.dataSliceIndex,
		// ControlPanel.error1SliceIndex, ControlPanel.error2SliceIndex, 2);

		JFrame frame = new JFrame("ViewSlice");
		ViewSlice viewsObj = null;
		BufferedImage bufView = null;

		String[] argsWalnutOrg = new String[12];

		argsWalnutOrg[0] = "-1";
		argsWalnutOrg[1] = "-x";
		argsWalnutOrg[2] = "2";
		argsWalnutOrg[3] = "-a";
		argsWalnutOrg[4] = "0";
		argsWalnutOrg[5] = "-l";
		argsWalnutOrg[6] = "gray";
		argsWalnutOrg[7] = "-min";
		argsWalnutOrg[8] = "";
		argsWalnutOrg[9] = "-max";
		argsWalnutOrg[10] = "";
		// argsWalnutOrg[11] = "walnut/walnut.xfdl";
		// argsWalnutOrg[11] = "headf/headf.bin.snr.d1.e4.fdl";
		argsWalnutOrg[11] = "data/tornadoTime-0.xfdl";

		viewsObj = new ViewSlice(frame, argsWalnutOrg);
		viewsObj.updateSlice2();
	}

	public static void primeCheck() {

		long starting_number = 2L;
		long ending_number = 10000L;
		long totals = 0;

		System.out.println("List of prime numbers between " + starting_number
				+ " and " + ending_number);

		for (long current = starting_number; current <= ending_number; current++) {
			long sqr_root = (long) Math.sqrt(current);
			boolean is_prime = true;
			for (long i = 2; i <= sqr_root; i++) {
				if (current % i == 0) {
					is_prime = false; // Current is not prime.
				}
			}
			if (is_prime) {
				System.out.println(current);
				totals++;
			}
		}
		System.out.println("There are a total of " + totals
				+ " prime numbers between " + starting_number + " and "
				+ ending_number);

	}
}
