#Assignment-3
#Submitted by
#Varsha Thirumakil

import time
import math
start = time.time()

for num in range(2,10000):
    if all(num%i!=0 for i in range(2,int(math.sqrt(num))+1)):
       print num



end = time.time()
elapsed = end - start
print "Time taken: ", elapsed, "seconds."



